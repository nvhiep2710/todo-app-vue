<template>
  <div>
    <div v-if="token" class="logout">
      <h4>Hello, {{infoUser.name}}</h4>
      <a @click="handleLogout">Logout</a>
    </div>
    <v-dialog />
    <notifications position="bottom right" />
    <router-view />
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
// import PopupLogout from "../PopupLogout";
export default {
  // components: {
  //   PopupLogout
  // },
  data() {
    return {
      isShow: false
    };
  },
  computed: {
    ...mapState("auth", ["infoUser", "token"])
  },
  methods: {
    ...mapActions("auth", ["logout"]),
    handleLogout() {
      this.$modal.show("dialog", {
        title: "Todo",
        text: "Do you want logout??",
        buttons: [
          {
            title: "Cancel"
          },
          {
            title: "Logout",
            default: true,
            handler: () => {
              this.logout();
              this.hide();
            }
          }
        ]
      });
    },
    hide() {
      this.$modal.hide("dialog");
    }
  }
};
</script>

<style lang="scss" scoped>
.logout {
  position: absolute;
  top: 0;
  right: 54px;
  display: flex;
  justify-content: center;
  align-items: center;
  a {
    margin-left: 15px;
    color: red;
    cursor: pointer;
  }
}
</style>